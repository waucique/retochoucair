package com.choucairtesting.empleo.testing.steps;

import static org.junit.Assert.assertThat;

import org.hamcrest.Matchers;

import com.choucairtesting.empleo.testing.pageobjects.EmpleoPageObject;

import net.thucydides.core.annotations.Step;

public class EmpleoSteps {
	
	EmpleoPageObject empleoPOM = new EmpleoPageObject();
	
	//Metodos
	
	@Step
	public void abrirApp() {
		empleoPOM.open();
	}
	
	@Step
	public void irAEmpleo() {
		empleoPOM.irAEmpleo();
	}
	
	@Step
	public void escribirPalabra(String palabra) {
		empleoPOM.escribirPalabra(palabra);	
	}
	
	@Step
	public void escribirLocalizacion(String localizacion) {
		empleoPOM.escribirLocalizacion(localizacion);
	}
	
	@Step
	public void clickBuscar() {
		empleoPOM.clickBuscar();
	}	
	
	@Step
	public void irPracticante() {
		empleoPOM.irPracticante();
	}
	
	@Step
	public void confirmarPracticante() {
		empleoPOM.confirmarPracticante();;
	}
	
	@Step
	public void irAnalista() {
		empleoPOM.irAnalista();
	}
	
	@Step
	public void confirmarCargo() {
		empleoPOM.confirmarCargo();
	}
	
	@Step
	public void confirmarPais() {
		empleoPOM.confirmarPais();
	}
	
	@Step
	public void confirmarAlerta() {
		empleoPOM.confirmarAlerta();
	}

}
