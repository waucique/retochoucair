package com.choucairtesting.empleo.testing.models;

public class Empleo {
	
	String palabra;
	String localizacion;
	
	//Constructor
	public Empleo(String palabra, String localizacion) {
		super();
		this.palabra = palabra;
		this.localizacion = localizacion;
	}

	//Getters
	public String getPalabra() {
		return palabra;
	}

	public String getLocalizacion() {
		return localizacion;
	}
	
	
	

}
